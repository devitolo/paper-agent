"""Two serial Gemini calls; default verifies inputs without invoking a model."""
import argparse,datetime,hashlib,json,os,pathlib,shutil,tempfile,time
from gemini_process import run_gemini
ROOT=pathlib.Path(__file__).resolve().parent
DIMENSIONS=['novelty','technical_depth','evidence','baseline_quality','operational_realism']

def verify(packet):
 ps=packet['passages']
 assert len(ps)<=8 and sum(len(p['text']) for p in ps)<=7000
 for p in ps:
  assert 0<len(p['text'])<=2000
  assert packet['regions'][p['region']]['text'][p['start']:p['end']]==p['text']

def validate(value,packet):
 assert isinstance(value,dict) and set(value['dimensions'])==set(DIMENSIONS)
 passages={p['id']:p['text'] for p in packet['passages']}
 for name,row in value['dimensions'].items():
  assert row['status'] in ['complete','unknown']
  if row['status']=='unknown': assert row['score'] is None
  else:
   assert type(row['score']) is int and 0<=row['score']<=4
   assert row.get('citations')
  assert isinstance(row['rationale'],str) and 0<len(row['rationale'])<=1200
  for c in row.get('citations',[]):
   assert isinstance(c['quote'],str) and c['quote'].strip()
   assert c['quote'] in passages[c['passage_id']]
 return value

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--model');args=ap.parse_args()
 manifest=json.loads((ROOT/'checksums.json').read_text())
 for filename,digest in manifest.items():
  assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()==digest,filename
 packets=[json.loads((ROOT/f'{name}-evidence.json').read_text()) for name in ['crystallization','teller']]
 for packet in packets:verify(packet)
 print('Verified: two packets, exact source slices, hashes, 7000-character/8-window/2000-character budgets.',flush=True)
 if not args.run:return
 if not shutil.which('gemini'):raise SystemExit('Gemini CLI not found; no calls made.')
 resultdir=pathlib.Path(tempfile.mkdtemp(prefix='paper-quality-results-')).resolve()
 print('Results:',resultdir,flush=True)
 for index,packet in enumerate(packets):
  prompt=(ROOT/f'prompt-{index+1}.txt').read_text();metadata={};started=time.monotonic()
  result={'paper':packet['paper'],'model_requested':args.model,'resolved_model':'unknown','usage':'unknown','prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'pdf_sha256':packet['pdf_sha256'],'status':'failed','semantic_support_review':'pending','scope':'manual development excerpts; not held-out; no automated-selection claim'}
  command=['gemini']+(['--model',args.model] if args.model else [])+['--output-format','stream-json','-p',prompt]
  old=os.getcwd()
  try:
   with tempfile.TemporaryDirectory(prefix='paper-quality-call-') as isolated:
    os.chdir(isolated)
    raw=run_gemini(command,180,stream_json=True,metadata=metadata)
   (resultdir/f'response-{index+1}.txt').write_text(raw)
   value=validate(json.loads(raw),packet)
   result.update(status='structurally_valid',assessment=value)
  except Exception as error:result['error_type']=type(error).__name__
  finally:os.chdir(old)
  result.update(elapsed_seconds=round(time.monotonic()-started,3),transport=metadata)
  (resultdir/f'result-{index+1}.json').write_text(json.dumps(result,indent=2))
  print(packet['paper'],result['status'],flush=True)
 print('Done. Two calls maximum; no retries. Exact quotations do not establish semantic support.',flush=True)
if __name__=='__main__':main()
