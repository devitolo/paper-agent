# Two-paper quality pilot
Run on the Mini with its existing authenticated Gemini CLI and Python 3.

    python3 run_pilot.py
    python3 run_pilot.py --run

Optional: append --model EXACT_MODEL_ID to pin an available model. Otherwise the CLI default is used and resolved identity is explicitly unknown, as is token usage (the existing transport does not expose these).

Default is conversion-free, model-free validation. --run makes at most two serial calls, 180 seconds each, zero retries, no fallback. The existing bounded repository Gemini transport is included unchanged from main 2a4b7ff. It validates stream completion and cleans child processes. Calls run in empty temporary directories; no review labels or local source paths enter prompts. Existing user/global Gemini configuration may still apply. A temporary results directory is printed; it preserves raw responses and per-paper reports. No database or production code is used.

Input budget: <=7000 selected characters per paper, <=8 windows, <=2000 characters each. Provider output is bounded by existing transport's 8 MiB stream ceiling and 180-second deadline, not a model token cap. Each result is checkpointed before the next call. Checksums cover input packets, prompts, and transport, not this README.

This is a manually curated development diagnostic; the selector has seen prior labels. Changed prompt AND changed evidence mean this is not a causal ablation of extraction alone. Full papers, all methods, figures and tables are not supplied. Unknown must remain unknown. Numeric ranking improvement and production acceptance cannot be inferred. Scored dimensions must cite exact supplied text; independent semantic review remains necessary.
